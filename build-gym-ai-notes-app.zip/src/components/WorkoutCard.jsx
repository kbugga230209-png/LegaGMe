const toneMap = {
  Back: {
    badge: "border-emerald-400/20 bg-emerald-500/10 text-emerald-300",
    glow: "from-emerald-500/18 via-emerald-400/5 to-transparent",
  },
  Chest: {
    badge: "border-red-400/20 bg-red-500/10 text-red-300",
    glow: "from-red-500/16 via-red-400/5 to-transparent",
  },
  Legs: {
    badge: "border-lime-400/20 bg-lime-500/10 text-lime-300",
    glow: "from-lime-500/16 via-lime-400/5 to-transparent",
  },
  Shoulders: {
    badge: "border-cyan-400/20 bg-cyan-500/10 text-cyan-300",
    glow: "from-cyan-500/16 via-cyan-400/5 to-transparent",
  },
  Arms: {
    badge: "border-fuchsia-400/20 bg-fuchsia-500/10 text-fuchsia-300",
    glow: "from-fuchsia-500/16 via-fuchsia-400/5 to-transparent",
  },
};

function formatTime(value) {
  if (!value) {
    return "Saved just now";
  }

  const date = new Date(value);

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export default function WorkoutCard({ workout, onDelete }) {
  const tone = toneMap[workout.muscle_group] ?? toneMap.Arms;

  return (
    <article className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.045] p-5 transition-all duration-300 hover:-translate-y-1 hover:border-emerald-400/20 hover:bg-white/[0.07] hover:shadow-[0_24px_80px_rgba(0,0,0,0.35)]">
      <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${tone.glow} opacity-80 transition duration-300 group-hover:opacity-100`} />
      <div className="relative z-10 flex flex-col gap-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-medium ${tone.badge}`}>
                {workout.muscle_group}
              </span>
              <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-medium ${workout.source === "ai" ? "border-emerald-400/20 bg-emerald-500/10 text-emerald-200" : "border-amber-400/20 bg-amber-500/10 text-amber-200"}`}>
                {workout.source === "ai" ? "Parsed by AI" : "Fallback Parser"}
              </span>
            </div>
            <h3 className="text-xl font-semibold text-white">{workout.exercise}</h3>
            {workout.rawInput ? <p className="mt-2 text-sm text-zinc-400">“{workout.rawInput}”</p> : null}
          </div>

          <button
            type="button"
            onClick={() => onDelete(workout.id)}
            className="rounded-2xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-zinc-300 transition hover:border-red-400/30 hover:bg-red-500/10 hover:text-red-200"
          >
            Delete
          </button>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Sets</p>
            <p className="mt-2 text-2xl font-semibold text-white">{workout.sets}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Reps</p>
            <p className="mt-2 text-2xl font-semibold text-white">{workout.reps}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Saved</p>
            <p className="mt-2 text-lg font-semibold text-white">{formatTime(workout.createdAt)}</p>
          </div>
        </div>
      </div>
    </article>
  );
}
