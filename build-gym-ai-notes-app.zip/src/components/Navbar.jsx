import { useMemo, useState, useEffect, useCallback } from "react";

export default function Navbar({ currentRoute, onNavigate, totalWorkouts, apiKey, onApiKeyChange }) {
  const [showApiPanel, setShowApiPanel] = useState(false);
  const [inputValue, setInputValue] = useState(apiKey ?? "");
  const [saveConfirmed, setSaveConfirmed] = useState(false);

  // Auto-open the API panel if no key is saved yet
  useEffect(() => {
    if (!apiKey) {
      setShowApiPanel(true);
    }
  }, []);

  // Sync input when apiKey prop changes (e.g. on initial load)
  useEffect(() => {
    setInputValue(apiKey ?? "");
  }, [apiKey]);

  const maskedKey = useMemo(() => {
    if (!apiKey) return "";
    if (apiKey.length <= 8) return "••••••••";
    return apiKey.slice(0, 4) + "••••" + apiKey.slice(-4);
  }, [apiKey]);

  const aiStatus = useMemo(() => {
    return apiKey ? "OpenRouter Connected" : "Fallback Parser Active";
  }, [apiKey]);

  const handleSaveKey = useCallback(() => {
    const trimmed = inputValue.trim();
    onApiKeyChange(trimmed);
    setSaveConfirmed(true);
    setTimeout(() => setSaveConfirmed(false), 2500);
  }, [inputValue, onApiKeyChange]);

  const handleClearKey = useCallback(() => {
    setInputValue("");
    onApiKeyChange("");
    setSaveConfirmed(false);
  }, [onApiKeyChange]);

  const handleKeyDown = useCallback(
    (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        handleSaveKey();
      }
    },
    [handleSaveKey],
  );

  const navItems = [
    { label: "Home", route: "/" },
    { label: "History", route: "/history" },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-black/35 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between lg:gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-400/20 bg-emerald-500/10 text-xl shadow-[0_0_40px_rgba(34,197,94,0.15)]">
                🧠
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.35em] text-emerald-300/80">Gym AI Notes</p>
                <h1 className="text-lg font-semibold text-white sm:text-xl">Premium workout logging with AI + voice</h1>
              </div>
            </div>

            <nav className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 p-1">
              {navItems.map((item) => {
                const active = currentRoute === item.route;

                return (
                  <button
                    key={item.route}
                    type="button"
                    onClick={() => onNavigate(item.route)}
                    className={`rounded-xl px-4 py-2 text-sm font-medium transition-all duration-200 ${
                      active
                        ? "bg-emerald-500 text-black shadow-[0_10px_30px_rgba(34,197,94,0.25)]"
                        : "text-zinc-300 hover:bg-white/8 hover:text-white"
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
              <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Total Workouts</p>
              <p className="mt-1 text-lg font-semibold text-white">{totalWorkouts}</p>
            </div>

            <div className={`rounded-2xl border px-4 py-3 ${apiKey ? "border-emerald-400/20 bg-emerald-500/10" : "border-red-400/20 bg-red-500/10"}`}>
              <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">AI Status</p>
              <p className={`mt-1 text-sm font-medium ${apiKey ? "text-emerald-300" : "text-red-300"}`}>{aiStatus}</p>
            </div>

            <button
              type="button"
              onClick={() => setShowApiPanel((current) => !current)}
              className="group flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-zinc-200 transition-all duration-200 hover:border-emerald-400/20 hover:bg-white/10 hover:text-white"
            >
              {showApiPanel ? "Hide API Key" : apiKey ? "Change API Key" : "Set API Key"}
              {apiKey && !showApiPanel && (
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-xs text-emerald-300">
                  {maskedKey}
                </span>
              )}
            </button>
          </div>
        </div>

        {showApiPanel ? (
          <div className="animate-fade-up rounded-3xl border border-white/10 bg-white/5 p-4 sm:p-5">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="max-w-3xl">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-white">OpenRouter API Key</p>
                  {apiKey && (
                    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-300">
                      <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                      Saved in browser
                    </span>
                  )}
                </div>
                <p className="mt-1 text-sm text-zinc-400">
                  Your key is stored in this browser's localStorage. It will persist across page reloads and sessions — you only need to enter it once.
                  If no key is present, the app still works using the built-in fallback parser.
                </p>
              </div>
              <div className="rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 text-xs text-red-200">
                Frontend-only keys are not secure for production.
              </div>
            </div>

            <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
              <label className="flex-1">
                <span className="mb-2 block text-xs uppercase tracking-[0.25em] text-zinc-500">API Key</span>
                <input
                  type="password"
                  value={inputValue}
                  onChange={(event) => setInputValue(event.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-full rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-white outline-none transition focus:border-emerald-400/40 focus:ring-2 focus:ring-emerald-500/20"
                  placeholder="sk-or-v1-..."
                  autoComplete="off"
                />
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSaveKey}
                  className={`inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold transition-all duration-200 ${
                    saveConfirmed
                      ? "bg-emerald-600 text-white"
                      : "bg-emerald-500 text-black hover:bg-emerald-400"
                  }`}
                >
                  {saveConfirmed ? (
                    <>
                      <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                      Saved!
                    </>
                  ) : (
                    "Save Key"
                  )}
                </button>
                {apiKey && (
                  <button
                    type="button"
                    onClick={handleClearKey}
                    className="rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-300 transition hover:bg-red-500/20"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {saveConfirmed && (
              <div className="mt-3 animate-fade-up flex items-center gap-2 rounded-2xl border border-emerald-400/20 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-200">
                <svg className="h-4 w-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                API key saved securely in your browser. It will persist across sessions — no need to re-enter it.
              </div>
            )}
          </div>
        ) : null}
      </div>
    </header>
  );
}
