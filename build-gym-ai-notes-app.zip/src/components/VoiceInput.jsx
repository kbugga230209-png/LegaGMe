import { useEffect, useMemo, useRef, useState } from "react";

export default function VoiceInput({ onTranscript }) {
  const recognitionRef = useRef(null);
  const transcriptRef = useRef("");
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState("");

  const SpeechRecognition = useMemo(() => {
    if (typeof window === "undefined") {
      return null;
    }

    return window.SpeechRecognition || window.webkitSpeechRecognition || null;
  }, []);

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop?.();
    };
  }, []);

  const startListening = () => {
    if (!SpeechRecognition) {
      setError("Voice input is not supported in this browser.");
      return;
    }

    transcriptRef.current = "";
    setError("");

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event) => {
      let transcript = "";

      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        transcript += event.results[index][0].transcript;
      }

      transcriptRef.current = transcript.trim();
    };

    recognition.onerror = (event) => {
      setError(event.error === "not-allowed" ? "Microphone access was denied." : "Voice recognition failed. Please try again.");
    };

    recognition.onend = () => {
      setIsListening(false);

      if (transcriptRef.current) {
        onTranscript(transcriptRef.current);
      }

      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    recognitionRef.current?.stop?.();
    setIsListening(false);
  };

  return (
    <div className="flex flex-col gap-2">
      <button
        type="button"
        onClick={isListening ? stopListening : startListening}
        className={`inline-flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-medium transition-all duration-200 ${
          isListening
            ? "border-red-400/30 bg-red-500/10 text-red-200 shadow-[0_0_0_6px_rgba(239,68,68,0.08)]"
            : "border-white/10 bg-white/5 text-zinc-200 hover:border-emerald-400/20 hover:bg-white/10 hover:text-white"
        }`}
      >
        <span className={`inline-flex h-2.5 w-2.5 rounded-full ${isListening ? "animate-pulse bg-red-400" : "bg-emerald-400"}`} />
        {isListening ? "Stop Recording" : "Voice Input"}
      </button>

      <p className="text-xs text-zinc-500">
        {SpeechRecognition ? "Tap once and speak naturally. Your transcript will autofill the workout input." : "Voice input requires a browser with Web Speech API support."}
      </p>

      {error ? <p className="text-xs text-red-300">{error}</p> : null}
    </div>
  );
}
