import { useMemo, useState } from "react";
import VoiceInput from "./VoiceInput.jsx";
import { parseWorkout } from "../utils/aiParser.js";
import { saveWorkout } from "../utils/storage.js";
import { formatDateKey } from "../utils/date.js";

const quickPrompts = [
  "Bench press 4x10",
  "Lat pulldown 3 sets of 12 reps",
  "Shoulder press 5x5",
];

export default function AddWorkout({ hasApiKey, onWorkoutSaved }) {
  const [inputText, setInputText] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [status, setStatus] = useState(null);
  const [latestWorkout, setLatestWorkout] = useState(null);

  const helperCopy = useMemo(() => {
    return hasApiKey
      ? "OpenRouter is connected. Entries will be parsed by AI first, with safe fallback handling if needed."
      : "No API key found. You can still log workouts with the built-in fallback parser, or add your OpenRouter key above for AI parsing.";
  }, [hasApiKey]);

  const handleTranscript = (transcript) => {
    setInputText((current) => (current ? `${current.trim()} ${transcript}` : transcript));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!inputText.trim()) {
      setStatus({
        type: "error",
        message: "Add some workout details before saving.",
      });
      return;
    }

    setIsSaving(true);
    setStatus(null);

    try {
      const parsedResult = await parseWorkout(inputText);
      const todayKey = formatDateKey(new Date());
      const savedWorkout = saveWorkout(todayKey, {
        ...parsedResult.workout,
        source: parsedResult.source,
        rawInput: inputText.trim(),
      });

      setLatestWorkout(savedWorkout);
      setInputText("");
      setStatus({
        type: parsedResult.warning ? "warning" : "success",
        message: parsedResult.warning
          ? `Saved successfully. ${parsedResult.warning}`
          : "Workout saved successfully.",
      });
      onWorkoutSaved(todayKey, savedWorkout);
    } catch (error) {
      setStatus({
        type: "error",
        message: error instanceof Error ? error.message : "Workout parsing failed.",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <section className="animate-fade-up rounded-[28px] border border-white/10 bg-white/[0.045] p-5 shadow-[0_30px_120px_rgba(0,0,0,0.35)] sm:p-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-emerald-300/80">Add workout</p>
          <h2 className="mt-2 text-2xl font-semibold text-white">Log a session with text or voice</h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-zinc-400">{helperCopy}</p>
        </div>
        <div className={`rounded-full border px-3 py-1 text-xs ${hasApiKey ? "border-emerald-400/20 bg-emerald-500/10 text-emerald-200" : "border-amber-400/20 bg-amber-500/10 text-amber-200"}`}>
          {hasApiKey ? "AI parsing enabled" : "Fallback mode"}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <label className="block">
          <span className="mb-2 block text-xs uppercase tracking-[0.25em] text-zinc-500">Workout input</span>
          <textarea
            value={inputText}
            onChange={(event) => setInputText(event.target.value)}
            rows={5}
            className="w-full resize-none rounded-3xl border border-white/10 bg-black/35 px-4 py-4 text-base text-white outline-none transition placeholder:text-zinc-600 focus:border-emerald-400/40 focus:ring-2 focus:ring-emerald-500/20"
            placeholder="Example: Bench press 4x10 or say your workout out loud"
          />
        </label>

        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <VoiceInput onTranscript={handleTranscript} />
            <button
              type="submit"
              disabled={isSaving}
              className="inline-flex items-center justify-center rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-semibold text-black transition-all duration-200 hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSaving ? "Analyzing workout..." : "Parse & Save Workout"}
            </button>
          </div>

          <div className="text-sm text-zinc-500">One exercise per entry works best for the cleanest AI JSON.</div>
        </div>
      </form>

      <div className="mt-5 flex flex-wrap gap-2">
        {quickPrompts.map((prompt) => (
          <button
            key={prompt}
            type="button"
            onClick={() => setInputText(prompt)}
            className="rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-zinc-300 transition hover:border-emerald-400/20 hover:bg-white/10 hover:text-white"
          >
            {prompt}
          </button>
        ))}
      </div>

      {status ? (
        <div
          className={`mt-5 rounded-2xl border px-4 py-3 text-sm ${
            status.type === "success"
              ? "border-emerald-400/20 bg-emerald-500/10 text-emerald-100"
              : status.type === "warning"
                ? "border-amber-400/20 bg-amber-500/10 text-amber-100"
                : "border-red-400/20 bg-red-500/10 text-red-100"
          }`}
        >
          {status.message}
        </div>
      ) : null}

      {latestWorkout ? (
        <div className="mt-5 rounded-3xl border border-white/10 bg-black/25 p-4">
          <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Last saved</p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <span className="text-lg font-semibold text-white">{latestWorkout.exercise}</span>
            <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-300">{latestWorkout.muscle_group}</span>
            <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-300">{latestWorkout.sets} sets</span>
            <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-300">{latestWorkout.reps} reps</span>
          </div>
        </div>
      ) : null}
    </section>
  );
}
