export const OPENROUTER_API_KEY_STORAGE_KEY = "gym-ai-notes.openrouter-key.v1";

const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions";
const OPENROUTER_MODEL = "mistralai/mistral-7b-instruct";
const ALLOWED_MUSCLE_GROUPS = ["Back", "Chest", "Legs", "Shoulders", "Arms"];

// SECURITY NOTE: This app stores and sends the OpenRouter API key directly from the frontend.
// That means the key can be exposed to end users and is not safe for production use.
// For a real production deployment, move AI requests to a secure backend or serverless proxy.
export function getStoredApiKey() {
  if (typeof window === "undefined") {
    return "";
  }

  return window.localStorage.getItem(OPENROUTER_API_KEY_STORAGE_KEY) ?? "";
}

export function saveApiKey(apiKey) {
  if (typeof window === "undefined") {
    return;
  }

  const normalizedKey = String(apiKey ?? "").trim();

  if (!normalizedKey) {
    window.localStorage.removeItem(OPENROUTER_API_KEY_STORAGE_KEY);
    return;
  }

  window.localStorage.setItem(OPENROUTER_API_KEY_STORAGE_KEY, normalizedKey);
}

function buildPrompt(inputText) {
  return `Convert the following gym workout into strict JSON.

Rules:

* Identify exercise name
* Identify muscle group (Back, Chest, Legs, Shoulders, Arms)
* Extract sets and reps as numbers
* Return ONLY valid JSON (no explanation)

Format:
{
"exercise": "",
"muscle_group": "",
"sets": 0,
"reps": 0
}

Workout:
${inputText}`;
}

function extractJsonString(content) {
  const match = content.match(/\{[\s\S]*\}/);
  return match ? match[0] : content;
}

function inferMuscleGroup(inputText) {
  const text = inputText.toLowerCase();

  const muscleMap = {
    Back: ["row", "lat pulldown", "pull-up", "pull up", "chin-up", "chin up", "deadlift", "back extension", "t-bar"],
    Chest: ["bench", "chest", "push-up", "push up", "incline press", "decline press", "pec deck", "fly"],
    Legs: ["squat", "lunge", "leg press", "leg curl", "leg extension", "calf", "hamstring", "glute", "rdl", "romanian deadlift"],
    Shoulders: ["shoulder press", "overhead press", "lateral raise", "front raise", "rear delt", "upright row", "shrug", "arnold press"],
    Arms: ["curl", "bicep", "tricep", "skull crusher", "hammer curl", "dip", "pushdown", "extension"],
  };

  for (const [muscleGroup, keywords] of Object.entries(muscleMap)) {
    if (keywords.some((keyword) => text.includes(keyword))) {
      return muscleGroup;
    }
  }

  return "Arms";
}

function cleanExerciseName(inputText) {
  const cleaned = inputText
    .replace(/\b(i did|did|completed|finished|today i did|today|worked on|logged)\b/gi, "")
    .replace(/\d+\s*[xX]\s*\d+/g, "")
    .replace(/\d+\s*sets?\s*(?:of)?\s*\d+\s*(?:reps?)?/gi, "")
    .replace(/\bfor\s+\d+\s+reps?\b/gi, "")
    .replace(/\breps?\b/gi, "")
    .replace(/\bsets?\b/gi, "")
    .replace(/[,:-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!cleaned) {
    return "Custom Exercise";
  }

  return cleaned
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function fallbackParse(inputText) {
  const directMatch = inputText.match(/(\d+)\s*[xX]\s*(\d+)/);
  const verboseMatch = inputText.match(/(\d+)\s*sets?\s*(?:of)?\s*(\d+)/i);
  const numbers = [...inputText.matchAll(/\d+/g)].map((match) => Number(match[0]));

  const sets = directMatch
    ? Number(directMatch[1])
    : verboseMatch
      ? Number(verboseMatch[1])
      : numbers[0] || 3;

  const reps = directMatch
    ? Number(directMatch[2])
    : verboseMatch
      ? Number(verboseMatch[2])
      : numbers[1] || 10;

  return validateWorkoutShape({
    exercise: cleanExerciseName(inputText),
    muscle_group: inferMuscleGroup(inputText),
    sets,
    reps,
  });
}

function validateWorkoutShape(candidate) {
  if (!candidate || typeof candidate !== "object") {
    return null;
  }

  const exercise = String(candidate.exercise ?? "").trim();
  const muscleGroup = String(candidate.muscle_group ?? "").trim();
  const sets = Number(candidate.sets);
  const reps = Number(candidate.reps);

  if (!exercise || !ALLOWED_MUSCLE_GROUPS.includes(muscleGroup)) {
    return null;
  }

  if (!Number.isFinite(sets) || !Number.isFinite(reps) || sets <= 0 || reps <= 0) {
    return null;
  }

  return {
    exercise,
    muscle_group: muscleGroup,
    sets: Math.round(sets),
    reps: Math.round(reps),
  };
}

export async function parseWorkout(inputText) {
  const cleanedInput = String(inputText ?? "").trim();

  if (!cleanedInput) {
    throw new Error("Please enter a workout before saving.");
  }

  const apiKey = getStoredApiKey();

  if (!apiKey) {
    return {
      workout: fallbackParse(cleanedInput),
      source: "fallback",
      warning: "No OpenRouter API key was found, so the local fallback parser was used.",
    };
  }

  try {
    const response = await fetch(OPENROUTER_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "HTTP-Referer": "http://localhost:5173",
        "X-Title": "Gym AI Notes App",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: OPENROUTER_MODEL,
        messages: [
          {
            role: "user",
            content: buildPrompt(cleanedInput),
          },
        ],
      }),
    });

    if (!response.ok) {
      let errorMessage = `OpenRouter request failed with status ${response.status}.`;

      try {
        const errorPayload = await response.json();
        errorMessage = errorPayload?.error?.message || errorPayload?.message || errorMessage;
      } catch {
        // Ignore JSON parsing errors and keep the fallback message.
      }

      return {
        workout: fallbackParse(cleanedInput),
        source: "fallback",
        warning: errorMessage,
      };
    }

    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;

    if (!content) {
      return {
        workout: fallbackParse(cleanedInput),
        source: "fallback",
        warning: "The AI response was empty, so the local fallback parser was used.",
      };
    }

    const parsedJson = JSON.parse(extractJsonString(content));
    const validatedWorkout = validateWorkoutShape(parsedJson);

    if (!validatedWorkout) {
      return {
        workout: fallbackParse(cleanedInput),
        source: "fallback",
        warning: "The AI returned invalid workout JSON, so the local fallback parser was used.",
      };
    }

    return {
      workout: validatedWorkout,
      source: "ai",
      warning: "",
    };
  } catch (error) {
    return {
      workout: fallbackParse(cleanedInput),
      source: "fallback",
      warning: error instanceof Error ? error.message : "AI parsing failed, so the local fallback parser was used.",
    };
  }
}
