const STORAGE_KEY = "gym-ai-notes.workouts.v1";

function canUseStorage() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function readStore() {
  if (!canUseStorage()) {
    return {};
  }

  try {
    const rawValue = window.localStorage.getItem(STORAGE_KEY);

    if (!rawValue) {
      return {};
    }

    const parsed = JSON.parse(rawValue);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function writeStore(store) {
  if (!canUseStorage()) {
    return;
  }

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
}

export function normalizeWorkout(workout) {
  if (!workout || typeof workout !== "object") {
    return null;
  }

  const exercise = String(workout.exercise ?? "").trim();
  const muscleGroup = String(workout.muscle_group ?? "").trim();
  const sets = Number(workout.sets);
  const reps = Number(workout.reps);

  if (!exercise || !muscleGroup || !Number.isFinite(sets) || !Number.isFinite(reps)) {
    return null;
  }

  if (sets <= 0 || reps <= 0) {
    return null;
  }

  return {
    ...workout,
    id: workout.id ? String(workout.id) : `workout-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    exercise,
    muscle_group: muscleGroup,
    sets: Math.round(sets),
    reps: Math.round(reps),
    createdAt: workout.createdAt ? String(workout.createdAt) : new Date().toISOString(),
    source: workout.source === "ai" ? "ai" : "fallback",
    rawInput: typeof workout.rawInput === "string" ? workout.rawInput : "",
  };
}

export function saveWorkout(date, workout) {
  const normalizedWorkout = normalizeWorkout(workout);

  if (!normalizedWorkout) {
    throw new Error("Workout data is invalid and could not be saved.");
  }

  const store = readStore();
  const existingWorkouts = Array.isArray(store[date]) ? store[date] : [];

  store[date] = [...existingWorkouts, normalizedWorkout];
  writeStore(store);

  return normalizedWorkout;
}

export function getWorkouts(date) {
  const store = readStore();
  const workouts = Array.isArray(store[date]) ? store[date] : [];

  return workouts.map(normalizeWorkout).filter(Boolean);
}

export function getAllWorkouts() {
  const store = readStore();
  const result = {};

  Object.entries(store).forEach(([date, workouts]) => {
    result[date] = Array.isArray(workouts) ? workouts.map(normalizeWorkout).filter(Boolean) : [];
  });

  return result;
}

export function deleteWorkout(date, workoutId) {
  const store = readStore();
  const existingWorkouts = Array.isArray(store[date]) ? store[date] : [];
  const filtered = existingWorkouts.filter((workout) => String(workout?.id) !== String(workoutId));

  if (filtered.length > 0) {
    store[date] = filtered;
  } else {
    delete store[date];
  }

  writeStore(store);
  return getAllWorkouts();
}
