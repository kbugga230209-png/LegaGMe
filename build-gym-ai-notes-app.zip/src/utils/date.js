export function formatDateKey(date = new Date()) {
  const value = date instanceof Date ? date : new Date(date);
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export function isToday(dateKey) {
  return dateKey === formatDateKey(new Date());
}

export function isYesterday(dateKey) {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return dateKey === formatDateKey(yesterday);
}

export function getRelativeLabel(dateKey) {
  if (isToday(dateKey)) {
    return "Today";
  }

  if (isYesterday(dateKey)) {
    return "Yesterday";
  }

  return null;
}

export function formatDisplayDate(dateKey) {
  const date = new Date(`${dateKey}T12:00:00`);

  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

export function formatShortDate(dateKey) {
  const date = new Date(`${dateKey}T12:00:00`);

  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
  }).format(date);
}

export function sortDateKeys(dateKeys = []) {
  return [...dateKeys].sort((a, b) => b.localeCompare(a));
}
