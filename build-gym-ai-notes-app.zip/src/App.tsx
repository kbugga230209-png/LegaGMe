// @ts-nocheck
import { useEffect, useMemo, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Home from "./pages/Home.jsx";
import History from "./pages/History.jsx";
import { deleteWorkout, getAllWorkouts } from "./utils/storage.js";
import { formatDateKey, sortDateKeys } from "./utils/date.js";
import { getStoredApiKey, saveApiKey } from "./utils/aiParser.js";

function getRouteFromHash() {
  if (typeof window === "undefined") {
    return "/";
  }

  const route = window.location.hash.replace("#", "") || "/";
  return route === "/history" ? "/history" : "/";
}

export default function App() {
  const todayKey = formatDateKey(new Date());
  const [route, setRoute] = useState(getRouteFromHash);
  const [allWorkouts, setAllWorkouts] = useState(() => getAllWorkouts());
  const [selectedDate, setSelectedDate] = useState(todayKey);
  const [apiKey, setApiKey] = useState(() => getStoredApiKey());

  const sortedDates = useMemo(() => sortDateKeys(Object.keys(allWorkouts)), [allWorkouts]);
  const totalWorkouts = useMemo(() => {
    return Object.values(allWorkouts).reduce((total, workouts) => total + workouts.length, 0);
  }, [allWorkouts]);
  const todayWorkouts = allWorkouts[todayKey] ?? [];

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(getRouteFromHash());
    };

    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  useEffect(() => {
    if (sortedDates.length === 0) {
      if (selectedDate !== todayKey) {
        setSelectedDate(todayKey);
      }
      return;
    }

    if (!selectedDate || !allWorkouts[selectedDate]) {
      setSelectedDate(sortedDates[0]);
    }
  }, [allWorkouts, selectedDate, sortedDates, todayKey]);

  const navigate = (nextRoute) => {
    if (typeof window !== "undefined") {
      window.location.hash = nextRoute;
    }

    setRoute(nextRoute);
  };

  const refreshWorkouts = () => {
    setAllWorkouts(getAllWorkouts());
  };

  const handleWorkoutSaved = (date) => {
    refreshWorkouts();
    setSelectedDate(date);
  };

  const handleDeleteWorkout = (date, workoutId) => {
    const updatedStore = deleteWorkout(date, workoutId);
    setAllWorkouts(updatedStore);
  };

  const handleApiKeyChange = (nextApiKey) => {
    saveApiKey(nextApiKey);
    setApiKey(getStoredApiKey());
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#0f0f0f] text-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-[-10rem] top-[-8rem] h-[22rem] w-[22rem] rounded-full bg-emerald-500/12 blur-3xl" />
        <div className="absolute right-[-8rem] top-16 h-[20rem] w-[20rem] rounded-full bg-red-500/10 blur-3xl" />
        <div className="glow-grid absolute inset-0 opacity-40" />
      </div>

      <div className="relative z-10">
        <Navbar
          currentRoute={route}
          onNavigate={navigate}
          totalWorkouts={totalWorkouts}
          apiKey={apiKey}
          onApiKeyChange={handleApiKeyChange}
        />

        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
          <section className="mb-8 rounded-[32px] border border-white/10 bg-white/[0.035] p-6 shadow-[0_40px_120px_rgba(0,0,0,0.35)] sm:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <p className="text-xs uppercase tracking-[0.35em] text-zinc-500">Local-first fitness journal</p>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2.5 py-0.5 text-[11px] text-emerald-300">
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Saved locally
                  </span>
                </div>
                <h1 className="mt-3 max-w-3xl text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                  Turn natural workout notes into clean, structured gym logs.
                </h1>
                <p className="mt-4 max-w-3xl text-sm leading-7 text-zinc-400 sm:text-base">
                  Gym AI Notes combines voice capture, OpenRouter-powered parsing, automatic muscle grouping,
                  and local browser storage in a premium, deploy-anywhere interface. All your data persists in this browser — nothing is ever deleted unless you choose to.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-3xl border border-white/10 bg-black/25 px-5 py-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Workout days</p>
                  <p className="mt-2 text-3xl font-semibold text-white">{sortedDates.length}</p>
                </div>
                <div className="rounded-3xl border border-white/10 bg-black/25 px-5 py-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Storage</p>
                  <p className="mt-2 text-sm font-medium text-emerald-300">Browser localStorage</p>
                  <p className="mt-1 text-xs text-zinc-500">Persistent across sessions</p>
                </div>
              </div>
            </div>
          </section>

          {route === "/history" ? (
            <History
              allWorkouts={allWorkouts}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              onDeleteWorkout={handleDeleteWorkout}
            />
          ) : (
            <Home
              todayKey={todayKey}
              workouts={todayWorkouts}
              hasApiKey={Boolean(apiKey)}
              onWorkoutSaved={handleWorkoutSaved}
              onDeleteWorkout={handleDeleteWorkout}
            />
          )}
        </main>

        <footer className="mx-auto max-w-7xl px-4 pb-8 text-sm text-zinc-500 sm:px-6 lg:px-8">
          <div className="rounded-3xl border border-white/10 bg-white/[0.035] px-5 py-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <svg className="h-4 w-4 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" /></svg>
                <span>
                  All data is stored permanently in this browser's localStorage. Your workouts and API key will persist across reloads and sessions.
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-0.5 text-emerald-300">
                  <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  {sortedDates.length} days saved
                </span>
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-0.5 text-emerald-300">
                  <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  {totalWorkouts} workouts saved
                </span>
                {apiKey && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-0.5 text-emerald-300">
                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                    API key saved
                  </span>
                )}
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
