import AddWorkout from "../components/AddWorkout.jsx";
import WorkoutCard from "../components/WorkoutCard.jsx";
import { formatDisplayDate, getRelativeLabel } from "../utils/date.js";

export default function Home({ todayKey, workouts, hasApiKey, onWorkoutSaved, onDeleteWorkout }) {
  const totalSets = workouts.reduce((sum, workout) => sum + workout.sets, 0);
  const muscleGroups = new Set(workouts.map((workout) => workout.muscle_group)).size;
  const relativeLabel = getRelativeLabel(todayKey) ?? "Today";

  return (
    <section className="grid gap-6 xl:grid-cols-[1.08fr_0.92fr]">
      <div className="space-y-6">
        <div className="rounded-[28px] border border-white/10 bg-white/[0.045] p-5 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs uppercase tracking-[0.35em] text-emerald-300/80">{relativeLabel}</p>
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-0.5 text-[11px] text-emerald-300">
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  Auto-saved
                </span>
              </div>
              <h2 className="mt-2 text-3xl font-semibold text-white">{formatDisplayDate(todayKey)}</h2>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-zinc-400">
                Capture every lift, rep, and set in one place. Use AI for structured parsing or log instantly with the local fallback parser.
              </p>
            </div>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/10 bg-black/25 p-4">
              <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Entries Today</p>
              <p className="mt-2 text-3xl font-semibold text-white">{workouts.length}</p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-black/25 p-4">
              <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Total Sets</p>
              <p className="mt-2 text-3xl font-semibold text-white">{totalSets}</p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-black/25 p-4">
              <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">Muscle Groups</p>
              <p className="mt-2 text-3xl font-semibold text-white">{muscleGroups}</p>
            </div>
          </div>
        </div>

        <AddWorkout hasApiKey={hasApiKey} onWorkoutSaved={onWorkoutSaved} />
      </div>

      <div className="rounded-[28px] border border-white/10 bg-white/[0.045] p-5 sm:p-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-zinc-500">Today's workout log</p>
            <h3 className="mt-2 text-2xl font-semibold text-white">Recent entries</h3>
          </div>
          <div className="flex items-center gap-2">
            <div className={`rounded-full border px-3 py-1 text-xs ${hasApiKey ? "border-emerald-400/20 bg-emerald-500/10 text-emerald-200" : "border-amber-400/20 bg-amber-500/10 text-amber-200"}`}>
              {hasApiKey ? "AI-assisted" : "Local parser"}
            </div>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          {workouts.length > 0 ? (
            workouts
              .slice()
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
              .map((workout, index) => (
                <div key={workout.id} style={{ animationDelay: `${index * 90}ms` }} className="animate-fade-up">
                  <WorkoutCard workout={workout} onDelete={(workoutId) => onDeleteWorkout(todayKey, workoutId)} />
                </div>
              ))
          ) : (
            <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-8 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-emerald-400/20 bg-emerald-500/10 text-2xl">
                💪
              </div>
              <h4 className="mt-4 text-xl font-semibold text-white">No workouts logged yet</h4>
              <p className="mt-2 text-sm leading-6 text-zinc-400">
                Add your first exercise above with text or voice. Today's entries will appear here automatically.
              </p>
              <p className="mt-2 text-xs text-zinc-500">
                All entries are saved permanently — they will still be here when you come back.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
