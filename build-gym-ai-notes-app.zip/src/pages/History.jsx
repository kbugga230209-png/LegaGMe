import WorkoutCard from "../components/WorkoutCard.jsx";
import { formatDisplayDate, formatShortDate, getRelativeLabel, sortDateKeys } from "../utils/date.js";

export default function History({ allWorkouts, selectedDate, onSelectDate, onDeleteWorkout }) {
  const dateKeys = sortDateKeys(Object.keys(allWorkouts));
  const selectedWorkouts = selectedDate ? allWorkouts[selectedDate] ?? [] : [];

  if (dateKeys.length === 0) {
    return (
      <section className="rounded-[28px] border border-white/10 bg-white/[0.045] p-8 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-black/25 text-2xl">
          📅
        </div>
        <h2 className="mt-4 text-2xl font-semibold text-white">No history yet</h2>
        <p className="mt-3 text-sm leading-6 text-zinc-400">
          Start logging workouts on the Home page and your full date-based history will appear here.
        </p>
        <p className="mt-2 text-xs text-zinc-500">
          All workouts are saved permanently in your browser — they will never be deleted unless you remove them manually.
        </p>
      </section>
    );
  }

  return (
    <section className="space-y-6">
      {/* Persistence banner */}
      <div className="flex items-center gap-3 rounded-2xl border border-emerald-400/15 bg-emerald-500/[0.06] px-4 py-3">
        <svg className="h-5 w-5 flex-shrink-0 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
        </svg>
        <div className="text-sm text-emerald-200/90">
          <span className="font-medium">Your workout history is permanent.</span>{" "}
          <span className="text-emerald-300/60">All {dateKeys.length} days and {Object.values(allWorkouts).reduce((s, w) => s + w.length, 0)} workouts are safely stored in your browser's localStorage.</span>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[340px_minmax(0,1fr)]">
        <aside className="rounded-[28px] border border-white/10 bg-white/[0.045] p-5 sm:p-6">
          <p className="text-xs uppercase tracking-[0.35em] text-emerald-300/80">History</p>
          <h2 className="mt-2 text-2xl font-semibold text-white">Browse previous dates</h2>
          <p className="mt-2 text-sm leading-6 text-zinc-400">Select a day to review the workouts stored locally in your browser. Your history is never cleared automatically.</p>

          <div className="mt-6 space-y-3">
            {dateKeys.map((dateKey) => {
              const workouts = allWorkouts[dateKey] ?? [];
              const active = selectedDate === dateKey;
              const label = getRelativeLabel(dateKey);

              return (
                <button
                  key={dateKey}
                  type="button"
                  onClick={() => onSelectDate(dateKey)}
                  className={`w-full rounded-3xl border p-4 text-left transition-all duration-200 ${
                    active
                      ? "border-emerald-400/30 bg-emerald-500/10 shadow-[0_16px_40px_rgba(34,197,94,0.12)]"
                      : "border-white/10 bg-black/20 hover:border-white/15 hover:bg-white/5"
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-lg font-semibold text-white">{formatShortDate(dateKey)}</p>
                      <p className="mt-1 text-sm text-zinc-400">{label ?? formatDisplayDate(dateKey)}</p>
                    </div>
                    <div className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-300">
                      {workouts.length} {workouts.length === 1 ? "entry" : "entries"}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="rounded-[28px] border border-white/10 bg-white/[0.045] p-5 sm:p-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-zinc-500">Selected date</p>
              <h2 className="mt-2 text-2xl font-semibold text-white">{formatDisplayDate(selectedDate)}</h2>
            </div>
            <div className="rounded-full border border-white/10 bg-black/25 px-3 py-1 text-xs text-zinc-300">
              {selectedWorkouts.length} {selectedWorkouts.length === 1 ? "workout" : "workouts"}
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {selectedWorkouts.length > 0 ? (
              selectedWorkouts
                .slice()
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map((workout, index) => (
                  <div key={workout.id} className="animate-fade-up" style={{ animationDelay: `${index * 90}ms` }}>
                    <WorkoutCard workout={workout} onDelete={(workoutId) => onDeleteWorkout(selectedDate, workoutId)} />
                  </div>
                ))
            ) : (
              <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-8 text-center text-sm text-zinc-400">
                No workouts are stored for this date.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
